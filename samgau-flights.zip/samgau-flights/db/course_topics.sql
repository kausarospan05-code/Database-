-- =====================================================================
--  Samgau Flights — database objects for the course topics that the
--  website itself does not need every day:
--    schemas · materialized view · functions · stored procedures ·
--    audit trigger · roles and privileges (GRANT / REVOKE) · indexes
--
--  Safe to run any number of times. The server runs it on every start
--  and setup runs it after promo_codes.sql. The demo queries that USE
--  these objects are in db/queries.sql, sorted by course topic.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. SCHEMAS — a separate namespace for reporting objects.
--    Live booking data stays in "public"; reports live in "analytics",
--    so an analyst can be given access to reports only.
-- ---------------------------------------------------------------------
CREATE SCHEMA IF NOT EXISTS analytics;

-- Daily sales: a normal view (always live, recomputed on every read)
CREATE OR REPLACE VIEW analytics.v_daily_sales AS
SELECT b.booking_date,
       COUNT(*)                         AS tickets,
       SUM(b.total_price)               AS revenue,
       ROUND(AVG(b.total_price))        AS avg_ticket
FROM BOOKING b
WHERE b.status <> 'Cancelled'
GROUP BY b.booking_date;

-- Route statistics: a MATERIALIZED view (stored result, refreshed on demand).
-- Reading it is instant; the heavy GROUP BY runs only on REFRESH.
CREATE MATERIALIZED VIEW IF NOT EXISTS analytics.mv_route_stats AS
SELECT f.origin, f.destination,
       COUNT(DISTINCT f.flight_id)                                       AS flights,
       COUNT(b.booking_id) FILTER (WHERE b.status <> 'Cancelled')        AS passengers,
       COALESCE(SUM(b.total_price) FILTER (WHERE b.status <> 'Cancelled'), 0) AS revenue,
       MIN(f.price)                                                      AS cheapest_fare
FROM FLIGHT f
LEFT JOIN BOOKING b ON b.flight_id = f.flight_id
GROUP BY f.origin, f.destination;
-- a unique index lets us refresh it without blocking readers (REFRESH ... CONCURRENTLY)
CREATE UNIQUE INDEX IF NOT EXISTS ux_mv_route_stats ON analytics.mv_route_stats (origin, destination);

-- ---------------------------------------------------------------------
-- 2. FUNCTIONS — return a value, can be used inside SELECT.
-- ---------------------------------------------------------------------
-- % of sellable seats already sold on one flight
CREATE OR REPLACE FUNCTION fn_load_factor(p_flight INT) RETURNS NUMERIC AS $$
    SELECT ROUND(100.0 * COUNT(b.booking_id) / NULLIF(COUNT(s.seat_id), 0), 1)
    FROM FLIGHT f
    JOIN SEAT s ON s.aircraft_id = f.aircraft_id AND s.status = 'Available'
    LEFT JOIN BOOKING b ON b.flight_id = f.flight_id AND b.seat_id = s.seat_id AND b.status <> 'Cancelled'
    WHERE f.flight_id = p_flight;
$$ LANGUAGE sql STABLE;

-- Great-circle distance in km between two airports (used in reports)
CREATE OR REPLACE FUNCTION fn_distance_km(p_from CHAR(3), p_to CHAR(3)) RETURNS INT AS $$
    SELECT round(6371 * 2 * asin(sqrt(
               power(sin(radians(d.latitude - o.latitude) / 2), 2) +
               cos(radians(o.latitude)) * cos(radians(d.latitude)) *
               power(sin(radians(d.longitude - o.longitude) / 2), 2))))::int
    FROM AIRPORT o, AIRPORT d WHERE o.code = p_from AND d.code = p_to;
$$ LANGUAGE sql STABLE;

-- ---------------------------------------------------------------------
-- 3. STORED PROCEDURES — perform actions, called with CALL, may COMMIT.
-- ---------------------------------------------------------------------
-- Delay a flight: moves all four times and marks it Delayed.
CREATE OR REPLACE PROCEDURE sp_delay_flight(p_flight INT, p_minutes INT) AS $$
BEGIN
    IF p_minutes <= 0 OR p_minutes > 1440 THEN
        RAISE EXCEPTION 'Delay must be between 1 and 1440 minutes';
    END IF;
    UPDATE FLIGHT
    SET departure_time = departure_time + make_interval(mins => p_minutes),
        arrival_time   = arrival_time   + make_interval(mins => p_minutes),
        departure_utc  = departure_utc  + make_interval(mins => p_minutes),
        arrival_utc    = arrival_utc    + make_interval(mins => p_minutes),
        status         = 'Delayed'
    WHERE flight_id = p_flight;
    IF NOT FOUND THEN RAISE EXCEPTION 'Flight % not found', p_flight; END IF;
    RAISE NOTICE 'Flight % delayed by % minutes', p_flight, p_minutes;
END $$ LANGUAGE plpgsql;

-- Switch off promo codes whose expiry date has passed.
CREATE OR REPLACE PROCEDURE sp_expire_promo_codes() AS $$
DECLARE n INT;
BEGIN
    UPDATE PROMO_CODE SET active = FALSE WHERE active AND valid_until < CURRENT_DATE;
    GET DIAGNOSTICS n = ROW_COUNT;
    RAISE NOTICE '% promo code(s) switched off', n;
END $$ LANGUAGE plpgsql;

-- Rebuild the stored report (see the materialized view above).
CREATE OR REPLACE PROCEDURE sp_refresh_reports() AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY analytics.mv_route_stats;
END $$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- 4. TRIGGERS — an audit log of every booking status change.
--    (The other trigger, trg_booking_seat, is in schema.sql.)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS BOOKING_AUDIT (
    audit_id    INT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    booking_id  INT          NOT NULL,
    booking_ref CHAR(6)      NOT NULL,
    old_status  VARCHAR(20),
    new_status  VARCHAR(20)  NOT NULL,
    changed_by  NAME         NOT NULL DEFAULT current_user,   -- which database role made the change
    changed_at  TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION fn_audit_booking_status() RETURNS trigger AS $$
BEGIN
    INSERT INTO BOOKING_AUDIT (booking_id, booking_ref, old_status, new_status)
    VALUES (NEW.booking_id, NEW.booking_ref, OLD.status, NEW.status);
    RETURN NEW;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_booking_audit ON BOOKING;
CREATE TRIGGER trg_booking_audit
AFTER UPDATE OF status ON BOOKING
FOR EACH ROW WHEN (OLD.status IS DISTINCT FROM NEW.status)
EXECUTE FUNCTION fn_audit_booking_status();

-- ---------------------------------------------------------------------
-- 5. INDEXES added for performance tuning (measured in queries.sql §13)
-- ---------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS ix_booking_date ON BOOKING (booking_date);
CREATE INDEX IF NOT EXISTS ix_payment_created ON PAYMENT (created_at);

-- ---------------------------------------------------------------------
-- 6. AUTHORIZATION — roles and privileges.
--    samgau_web     : what the website needs, nothing more (no DROP, no DELETE on most tables)
--    samgau_analyst : read-only, and only the "analytics" schema + safe columns
--    Roles are shared by the whole PostgreSQL server, so they are created once.
--    Change these demo passwords before any real use.
-- ---------------------------------------------------------------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'samgau_web') THEN
        CREATE ROLE samgau_web LOGIN PASSWORD 'web_demo_2026';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'samgau_analyst') THEN
        CREATE ROLE samgau_analyst LOGIN PASSWORD 'analyst_demo_2026';
    END IF;
    EXECUTE format('GRANT CONNECT ON DATABASE %I TO samgau_web, samgau_analyst', current_database());
END $$;

-- Website role: read + write data, but cannot delete bookings or change the structure
GRANT USAGE ON SCHEMA public TO samgau_web;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO samgau_web;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO samgau_web;
GRANT DELETE ON PROMO_REDEMPTION TO samgau_web;            -- the only DELETE the site does (code given back)
REVOKE DELETE, TRUNCATE ON BOOKING, PAYMENT, PASSENGER, APP_USER FROM samgau_web;
GRANT EXECUTE ON FUNCTION fn_promo_check(TEXT, INT, NUMERIC) TO samgau_web;

-- Analyst role: reports only
GRANT USAGE ON SCHEMA analytics TO samgau_analyst;
GRANT SELECT ON ALL TABLES IN SCHEMA analytics TO samgau_analyst;
-- column-level privilege: may see promo codes and their usage, nothing else in public
GRANT USAGE ON SCHEMA public TO samgau_analyst;
GRANT SELECT (code, description, discount_percent, discount_amount, valid_until, max_uses, used_count, active)
    ON PROMO_CODE TO samgau_analyst;
REVOKE ALL ON APP_USER, PAYMENT, PASSENGER FROM samgau_analyst;     -- never passwords, cards or personal data
