-- =====================================================================
--  Samgau Flights — query examples, one section per course topic.
--  Open in pgAdmin (Query Tool), select one query and press F5.
--  Every query here is safe to run: changes are rolled back, and the
--  "refused" examples catch their own error and print it as a NOTICE
--  (pgAdmin: see the Messages tab).
--
--   1  Joins and expressions          8  Functions and procedures
--   2  Views                          9  Triggers
--   3  Transactions                  10  Recursive queries
--   4  Integrity constraints         11  Advanced aggregation
--   5  Data types and schemas        12  Window functions
--   6  Indexes                       13  Query optimization and tuning
--   7  Authorization
-- =====================================================================


-- =====================================================================
-- 1. JOINS AND EXPRESSIONS
-- =====================================================================

-- INNER JOIN across 5 tables: tomorrow's departures board
SELECT f.flight_number, f.airline, o.city AS from_city, d.city AS to_city,
       f.departure_time, f.arrival_time, g.gate_number, g.terminal,
       a.manufacturer || ' ' || a.model AS aircraft               -- string expression
FROM FLIGHT f
JOIN AIRPORT o   ON o.code = f.origin
JOIN AIRPORT d   ON d.code = f.destination
LEFT JOIN GATE g ON g.gate_id = f.gate_id
LEFT JOIN AIRCRAFT a ON a.aircraft_id = f.aircraft_id
WHERE f.departure_time >= CURRENT_DATE + 1 AND f.departure_time < CURRENT_DATE + 2
ORDER BY f.departure_time
LIMIT 30;

-- LEFT JOIN: every passenger, with bookings if any (NULL when none)
SELECT p.first_name, p.last_name, b.booking_ref, b.status
FROM PASSENGER p
LEFT JOIN BOOKING b ON p.passenger_id = b.passenger_id
ORDER BY p.passenger_id DESC
LIMIT 20;

-- RIGHT JOIN: every aircraft and how many flights it operates
SELECT a.registration, a.model, a.capacity, COUNT(f.flight_id) AS flights
FROM FLIGHT f
RIGHT JOIN AIRCRAFT a ON f.aircraft_id = a.aircraft_id
GROUP BY a.aircraft_id
ORDER BY flights DESC;

-- FULL OUTER JOIN: airlines and airports matched by hub (shows airports that are nobody's hub)
SELECT l.name AS airline, ap.city AS hub_city
FROM AIRLINE l
FULL OUTER JOIN AIRPORT ap ON ap.code = l.hub
ORDER BY ap.region, ap.city;

-- SELF-JOIN: connecting flights Shymkent → London, changing in Almaty or Astana,
-- with 1½–12 hours to change planes
SELECT f1.flight_number AS first_leg, f1.origin || '→' || f1.destination AS leg1, f1.departure_time,
       f2.flight_number AS second_leg, f2.origin || '→' || f2.destination AS leg2, f2.arrival_time,
       f2.departure_utc - f1.arrival_utc AS layover,
       f1.price + f2.price AS total_fare
FROM FLIGHT f1
JOIN FLIGHT f2 ON f2.origin = f1.destination
              AND f2.departure_utc BETWEEN f1.arrival_utc + interval '90 minutes' AND f1.arrival_utc + interval '12 hours'
WHERE f1.origin = 'CIT' AND f2.destination = 'LHR'
  AND f1.departure_time >= CURRENT_DATE + 3 AND f1.departure_time < CURRENT_DATE + 4
ORDER BY total_fare
LIMIT 10;

-- Expressions: CASE, COALESCE, NULLIF, arithmetic on dates and numbers, subquery
SELECT f.flight_number,
       f.arrival_utc - f.departure_utc                               AS duration,      -- interval arithmetic
       f.price, f.business_price,
       ROUND(f.business_price / NULLIF(f.price, 0), 1)               AS business_ratio,
       CASE WHEN f.price < 30000 THEN 'Budget'
            WHEN f.price < 150000 THEN 'Standard'
            ELSE 'Premium' END                                       AS price_band,
       COALESCE(g.gate_number, 'TBA')                                AS gate,
       f.price > (SELECT AVG(price) FROM FLIGHT WHERE origin = f.origin) AS above_avg_from_origin
FROM FLIGHT f LEFT JOIN GATE g ON g.gate_id = f.gate_id
WHERE f.origin = 'ALA' AND f.departure_time >= CURRENT_DATE + 1 AND f.departure_time < CURRENT_DATE + 2
ORDER BY f.price;


-- =====================================================================
-- 2. VIEWS
-- =====================================================================

-- A view used by the website: seats left per class for every flight (schema.sql)
SELECT * FROM v_flight_availability WHERE flight_id = 100;

-- A view that joins 7 tables into one readable row per ticket (schema.sql)
SELECT booking_ref, first_name, flight_number, origin, destination, seat_number, payment_method, total_price
FROM v_booking_details WHERE booking_ref = 'SMG7K2';

-- A view in the "analytics" schema (course_topics.sql)
SELECT * FROM analytics.v_daily_sales ORDER BY booking_date DESC LIMIT 7;

-- A MATERIALIZED view: a stored result, fast to read, refreshed on demand
SELECT * FROM analytics.mv_route_stats ORDER BY revenue DESC LIMIT 10;
CALL sp_refresh_reports();          -- = REFRESH MATERIALIZED VIEW CONCURRENTLY analytics.mv_route_stats


-- =====================================================================
-- 3. TRANSACTIONS
--    The website books every ticket inside BEGIN … COMMIT (server.js,
--    POST /api/bookings): if any step fails, ROLLBACK undoes all of it.
--    Demo below: change prices, look, then undo everything.
-- =====================================================================
BEGIN;
    UPDATE FLIGHT SET price = price * 0.5 WHERE origin = 'NQZ' AND destination = 'ALA';
    SELECT flight_number, price FROM FLIGHT WHERE origin = 'NQZ' AND destination = 'ALA' ORDER BY departure_time LIMIT 3;
    SAVEPOINT before_delete;
    UPDATE FLIGHT SET status = 'Cancelled' WHERE origin = 'NQZ' AND destination = 'ALA';
    ROLLBACK TO SAVEPOINT before_delete;          -- undo only the second step
ROLLBACK;                                         -- undo everything: prices are back
SELECT flight_number, price FROM FLIGHT WHERE origin = 'NQZ' AND destination = 'ALA' ORDER BY departure_time LIMIT 3;

-- Row locking inside a transaction (what the website does before selling seats):
-- a second session running the same SELECT … FOR UPDATE waits until this one ends.
BEGIN;
    SELECT flight_id, flight_number FROM FLIGHT WHERE flight_id = 100 FOR UPDATE;
ROLLBACK;


-- =====================================================================
-- 4. INTEGRITY CONSTRAINTS
--    PRIMARY KEY, FOREIGN KEY, UNIQUE, NOT NULL, CHECK, partial UNIQUE index.
--    Each block below breaks one rule; PostgreSQL refuses it.
-- =====================================================================

-- Selling a seat twice → partial unique index ux_booking_flight_seat
DO $$ BEGIN
    INSERT INTO BOOKING (booking_ref, passenger_id, flight_id, seat_id, fare, total_price)
    SELECT 'TEST01', 3, flight_id, seat_id, 0, 0 FROM BOOKING WHERE booking_ref = 'SMG7K2' LIMIT 1;
EXCEPTION WHEN unique_violation THEN RAISE NOTICE 'Refused (UNIQUE): %', SQLERRM;
END $$;

-- Arrival before departure → CHECK (arrival_utc > departure_utc)
DO $$ BEGIN
    UPDATE FLIGHT SET arrival_utc = departure_utc - interval '1 hour' WHERE flight_id = 100;
EXCEPTION WHEN check_violation THEN RAISE NOTICE 'Refused (CHECK): %', SQLERRM;
END $$;

-- A flight from an airport that does not exist → FOREIGN KEY
DO $$ BEGIN
    UPDATE FLIGHT SET origin = 'XXX' WHERE flight_id = 100;
EXCEPTION WHEN foreign_key_violation THEN RAISE NOTICE 'Refused (FOREIGN KEY): %', SQLERRM;
END $$;

-- A promo code with both % and ₸ discount → CHECK ((discount_percent IS NULL) <> (discount_amount IS NULL))
DO $$ BEGIN
    INSERT INTO PROMO_CODE (code, discount_percent, discount_amount, valid_until) VALUES ('BADCODE', 10, 500, '2027-01-01');
EXCEPTION WHEN check_violation THEN RAISE NOTICE 'Refused (CHECK): %', SQLERRM;
END $$;

-- A booking with no passenger name → NOT NULL
DO $$ BEGIN
    INSERT INTO PASSENGER (first_name, last_name) VALUES (NULL, 'Test');
EXCEPTION WHEN not_null_violation THEN RAISE NOTICE 'Refused (NOT NULL): %', SQLERRM;
END $$;

-- Every constraint in the project, listed from the system catalog
SELECT conrelid::regclass AS table_name, conname AS constraint_name,
       CASE contype WHEN 'p' THEN 'PRIMARY KEY' WHEN 'f' THEN 'FOREIGN KEY' WHEN 'u' THEN 'UNIQUE' WHEN 'c' THEN 'CHECK' END AS kind,
       pg_get_constraintdef(oid) AS definition
FROM pg_constraint
WHERE connamespace = 'public'::regnamespace
ORDER BY table_name, kind;


-- =====================================================================
-- 5. SQL DATA TYPES AND SCHEMAS
-- =====================================================================

-- The column types of FLIGHT: INT identity, VARCHAR, CHAR(3), TIMESTAMP, NUMERIC(10,2)…
SELECT column_name, data_type, character_maximum_length AS max_len, numeric_precision, numeric_scale,
       is_nullable, column_default
FROM information_schema.columns
WHERE table_name = 'flight' ORDER BY ordinal_position;

-- Special types in use: GENERATED column, BOOLEAN, TIMESTAMPTZ, arrays, intervals
SELECT registration, seat_rows, seat_letters, capacity          -- capacity = seat_rows * length(seat_letters), GENERATED ALWAYS … STORED
FROM AIRCRAFT LIMIT 5;
SELECT code, active, valid_until - CURRENT_DATE AS days_left    -- BOOLEAN, DATE − DATE = integer days
FROM PROMO_CODE;
SELECT now() AS timestamptz_now, now() AT TIME ZONE 'UTC' AS utc_timestamp,
       '2026-12-31'::date - CURRENT_DATE AS days_to_new_year, interval '4 hours 50 minutes' * 2 AS doubled;

-- Schemas: "public" holds the live data, "analytics" holds reports
SELECT table_schema, table_name, table_type
FROM information_schema.tables
WHERE table_schema IN ('public', 'analytics')
ORDER BY table_schema, table_type, table_name;


-- =====================================================================
-- 6. INDEX DEFINITION
-- =====================================================================

-- All indexes, with what they cover (schema.sql + course_topics.sql)
SELECT tablename, indexname, indexdef
FROM pg_indexes
WHERE schemaname IN ('public', 'analytics')
ORDER BY tablename, indexname;

-- Kinds used in the project:
--   composite   CREATE INDEX ix_flight_route_time ON FLIGHT (origin, destination, departure_time);
--   partial     CREATE INDEX ix_booking_flight ON BOOKING (flight_id) WHERE status <> 'Cancelled';
--   unique+partial  CREATE UNIQUE INDEX ux_booking_flight_seat ON BOOKING (flight_id, seat_id) WHERE status <> 'Cancelled';
--   on a materialized view  CREATE UNIQUE INDEX ux_mv_route_stats ON analytics.mv_route_stats (origin, destination);

-- How often each index has been used since the server started
SELECT relname AS table_name, indexrelname AS index_name, idx_scan AS times_used
FROM pg_stat_user_indexes ORDER BY idx_scan DESC LIMIT 15;


-- =====================================================================
-- 7. AUTHORIZATION (roles, GRANT, REVOKE — created in course_topics.sql)
--    samgau_web     : the website — read/write data, cannot delete bookings
--    samgau_analyst : reports only, cannot see passwords, cards, passengers
--    The website itself also has app-level roles: APP_USER.role = 'customer' | 'admin'.
-- =====================================================================

-- Who has which privilege on which table
SELECT grantee, table_schema, table_name, string_agg(privilege_type, ', ' ORDER BY privilege_type) AS privileges
FROM information_schema.role_table_grants
WHERE grantee IN ('samgau_web', 'samgau_analyst')
GROUP BY grantee, table_schema, table_name
ORDER BY grantee, table_schema, table_name;

-- Column-level privilege: the analyst may read only some PROMO_CODE columns
SELECT grantee, table_name, column_name, privilege_type
FROM information_schema.column_privileges
WHERE grantee = 'samgau_analyst';

-- Try it: act as the analyst
SET ROLE samgau_analyst;
SELECT * FROM analytics.mv_route_stats LIMIT 3;                      -- allowed
SELECT code, used_count, max_uses FROM PROMO_CODE;                  -- allowed (granted columns)
DO $$ BEGIN PERFORM email FROM APP_USER LIMIT 1;                    -- refused
EXCEPTION WHEN insufficient_privilege THEN RAISE NOTICE 'Refused for analyst: %', SQLERRM; END $$;
RESET ROLE;

-- Act as the website role
SET ROLE samgau_web;
DO $$ BEGIN DELETE FROM BOOKING WHERE booking_id = 1;               -- refused: bookings are cancelled, never deleted
EXCEPTION WHEN insufficient_privilege THEN RAISE NOTICE 'Refused for website: %', SQLERRM; END $$;
RESET ROLE;


-- =====================================================================
-- 8. FUNCTIONS AND PROCEDURES
--    Functions return a value (used in SELECT); procedures do work (CALL).
-- =====================================================================

-- fn_promo_check (promo_codes.sql): the website's promo-code rules
SELECT * FROM fn_promo_check('STUDENT10', 1, 120000);    -- ok, 12 000 ₸ off
SELECT * FROM fn_promo_check('SUMMER15', 1, 120000);     -- expired
SELECT * FROM fn_promo_check('LASTONE', 1, 120000);      -- usage limit reached

-- fn_load_factor and fn_distance_km (course_topics.sql) used inside a query
SELECT f.flight_number, f.origin, f.destination,
       fn_distance_km(f.origin, f.destination) AS km,
       fn_load_factor(f.flight_id)             AS load_pct
FROM FLIGHT f
WHERE f.departure_time >= CURRENT_DATE + 1 AND f.departure_time < CURRENT_DATE + 2 AND f.origin = 'NQZ'
ORDER BY load_pct DESC;

-- Procedures (inside a transaction so the demo changes nothing)
BEGIN;
    CALL sp_delay_flight(100, 45);                                   -- NOTICE: Flight 100 delayed by 45 minutes
    SELECT flight_number, departure_time, status FROM FLIGHT WHERE flight_id = 100;
ROLLBACK;
CALL sp_refresh_reports();
-- CALL sp_expire_promo_codes();   -- switches off expired codes (changes data)


-- =====================================================================
-- 9. TRIGGERS
--    trg_booking_seat  (schema.sql)        BEFORE INSERT/UPDATE: seat must be on that flight's plane
--    trg_booking_audit (course_topics.sql) AFTER UPDATE OF status: writes BOOKING_AUDIT
-- =====================================================================

-- The seat trigger refuses a seat from another aircraft
DO $$ BEGIN
    INSERT INTO BOOKING (booking_ref, passenger_id, flight_id, seat_id, fare, total_price)
    VALUES ('TEST02', 3, 100, (SELECT MAX(seat_id) FROM SEAT), 0, 0);
EXCEPTION WHEN check_violation THEN RAISE NOTICE 'Refused by trigger: %', SQLERRM;
END $$;

-- The audit trigger logs a status change automatically
BEGIN;
    UPDATE BOOKING SET status = 'Cancelled' WHERE booking_ref = 'SMG7K2';
    SELECT * FROM BOOKING_AUDIT ORDER BY audit_id DESC LIMIT 2;      -- two rows appeared by themselves
ROLLBACK;

-- Every cancellation made on the website, from the audit log
SELECT booking_ref, old_status, new_status, changed_by, changed_at FROM BOOKING_AUDIT ORDER BY changed_at DESC LIMIT 20;

-- All triggers in the project
SELECT event_object_table AS table_name, trigger_name, action_timing, event_manipulation, action_statement
FROM information_schema.triggers ORDER BY table_name;


-- =====================================================================
-- 10. RECURSIVE QUERIES (WITH RECURSIVE)
-- =====================================================================

-- Every city you can reach from Shymkent with at most 2 changes, and the shortest path
WITH RECURSIVE routes AS (
    SELECT DISTINCT origin, destination FROM FLIGHT WHERE departure_utc > now() AT TIME ZONE 'UTC'
),
trip (city, path, changes) AS (
    SELECT 'CIT'::char(3), ARRAY['CIT']::text[], -1               -- start: Shymkent
    UNION ALL
    SELECT r.destination, t.path || r.destination::text, t.changes + 1
    FROM trip t JOIN routes r ON r.origin = t.city
    WHERE t.changes < 2 AND NOT r.destination::text = ANY (t.path)   -- stop: max 2 changes, no loops
)
SELECT DISTINCT ON (city) city, changes, array_to_string(path, ' → ') AS shortest_path
FROM trip WHERE city <> 'CIT'
ORDER BY city, changes;

-- How many cities are reachable after 0, 1 and 2 changes
WITH RECURSIVE routes AS (SELECT DISTINCT origin, destination FROM FLIGHT),
reach (city, hops) AS (
    SELECT 'CIT'::char(3), 0
    UNION
    SELECT r.destination, h.hops + 1 FROM reach h JOIN routes r ON r.origin = h.city WHERE h.hops < 3
)
SELECT hops - 1 AS changes, COUNT(DISTINCT city) AS cities
FROM (SELECT city, MIN(hops) AS hops FROM reach GROUP BY city) x
WHERE hops > 0 GROUP BY hops ORDER BY hops;

-- A recursive number generator: the next 7 days with flight counts
WITH RECURSIVE days (d) AS (
    SELECT CURRENT_DATE
    UNION ALL
    SELECT d + 1 FROM days WHERE d < CURRENT_DATE + 6
)
SELECT d AS day, to_char(d, 'Dy') AS weekday,
       (SELECT COUNT(*) FROM FLIGHT f WHERE f.departure_time >= d AND f.departure_time < d + 1) AS flights
FROM days;


-- =====================================================================
-- 11. ADVANCED AGGREGATION FEATURES
--     ROLLUP, CUBE, GROUPING SETS, GROUPING(), FILTER, HAVING,
--     ordered-set aggregates (percentile), string_agg
-- =====================================================================

-- ROLLUP: revenue per airline per class, + a subtotal per airline + a grand total
SELECT CASE WHEN GROUPING(f.airline) = 1 THEN '== ALL AIRLINES ==' ELSE f.airline END AS airline,
       CASE WHEN GROUPING(s.class) = 1 THEN '(all classes)' ELSE s.class END        AS class,
       COUNT(*) AS tickets, SUM(b.total_price) AS revenue
FROM BOOKING b
JOIN FLIGHT f ON f.flight_id = b.flight_id
JOIN SEAT s   ON s.seat_id = b.seat_id
WHERE b.status <> 'Cancelled' AND f.airline IN ('Air Astana', 'Turkish Airlines', 'Emirates')
GROUP BY ROLLUP (f.airline, s.class)
ORDER BY GROUPING(f.airline), f.airline, GROUPING(s.class), s.class;

-- CUBE: every combination of origin region × booking status
SELECT COALESCE(o.region, 'ALL') AS from_region, COALESCE(b.status, 'ALL') AS status, COUNT(*) AS bookings
FROM BOOKING b JOIN FLIGHT f ON f.flight_id = b.flight_id JOIN AIRPORT o ON o.code = f.origin
GROUP BY CUBE (o.region, b.status)
ORDER BY GROUPING(o.region), o.region, GROUPING(b.status), b.status;

-- GROUPING SETS: three separate summaries in one query
SELECT f.airline, pm.method_name, s.class, COUNT(*) AS tickets
FROM BOOKING b
JOIN FLIGHT f ON f.flight_id = b.flight_id
JOIN SEAT s ON s.seat_id = b.seat_id
JOIN PAYMENT_METHOD pm ON pm.payment_id = b.payment_id
WHERE b.status <> 'Cancelled'
GROUP BY GROUPING SETS ((f.airline), (pm.method_name), (s.class))
ORDER BY f.airline NULLS LAST, pm.method_name NULLS LAST, s.class;

-- FILTER + HAVING + percentile + string_agg: airline scorecard
SELECT f.airline,
       COUNT(*)                                                    AS bookings,
       COUNT(*) FILTER (WHERE b.status = 'Cancelled')              AS cancelled,
       ROUND(100.0 * COUNT(*) FILTER (WHERE b.status = 'Cancelled') / COUNT(*), 1) AS cancel_pct,
       percentile_cont(0.5) WITHIN GROUP (ORDER BY b.total_price)  AS median_ticket,
       string_agg(DISTINCT f.origin, ', ')                         AS departs_from
FROM BOOKING b JOIN FLIGHT f ON f.flight_id = b.flight_id
GROUP BY f.airline
HAVING COUNT(*) > 1000
ORDER BY bookings DESC;

-- Payments per method, paid vs refunded (FILTER)
SELECT pm.method_name,
       COUNT(*) FILTER (WHERE p.status = 'Paid')                      AS payments,
       COALESCE(SUM(p.amount) FILTER (WHERE p.status = 'Paid'), 0)     AS paid,
       COALESCE(SUM(p.amount) FILTER (WHERE p.status = 'Refunded'), 0) AS refunded,
       COALESCE(SUM(p.discount), 0)                                   AS promo_discounts
FROM PAYMENT_METHOD pm LEFT JOIN PAYMENT p ON p.payment_id = pm.payment_id
GROUP BY pm.method_name ORDER BY paid DESC;


-- =====================================================================
-- 12. WINDOW FUNCTIONS
--     ROW_NUMBER, RANK, DENSE_RANK, LAG, running SUM, moving AVG, NTILE, PERCENT_RANK
-- =====================================================================

-- ROW_NUMBER: each airline's 3 busiest routes
SELECT * FROM (
    SELECT f.airline, f.origin || ' → ' || f.destination AS route, COUNT(*) AS passengers,
           ROW_NUMBER() OVER (PARTITION BY f.airline ORDER BY COUNT(*) DESC) AS rn
    FROM BOOKING b JOIN FLIGHT f ON f.flight_id = b.flight_id
    WHERE b.status <> 'Cancelled'
    GROUP BY f.airline, f.origin, f.destination
) t
WHERE rn <= 3
ORDER BY airline, rn;

-- RANK: the cheapest flight per route for each of the next 3 days
SELECT * FROM (
    SELECT f.origin, f.destination, f.departure_time::date AS day, f.flight_number, f.price,
           RANK() OVER (PARTITION BY f.origin, f.destination, f.departure_time::date ORDER BY f.price) AS rnk
    FROM FLIGHT f
    WHERE f.origin = 'NQZ' AND f.departure_time >= CURRENT_DATE + 1 AND f.departure_time < CURRENT_DATE + 4
) t
WHERE rnk = 1
ORDER BY destination, day;

-- LAG: how the fare of one flight number changes from day to day
SELECT flight_number, departure_time::date AS day, price,
       price - LAG(price) OVER (PARTITION BY flight_number ORDER BY departure_time) AS change_vs_previous_day
FROM FLIGHT
WHERE flight_number = (SELECT flight_number FROM FLIGHT WHERE origin = 'IST' AND destination = 'LHR' LIMIT 1)
ORDER BY departure_time;

-- Running total and 7-day moving average of daily sales
SELECT booking_date, tickets, revenue,
       SUM(revenue) OVER (ORDER BY booking_date)                                       AS running_total,
       ROUND(AVG(revenue) OVER (ORDER BY booking_date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW)) AS moving_avg_7d
FROM analytics.v_daily_sales
ORDER BY booking_date;

-- NTILE + PERCENT_RANK: split tomorrow's flights into 4 groups by how full they are
SELECT flight_number, origin, destination, load_pct,
       NTILE(4) OVER (ORDER BY load_pct DESC)                   AS quartile,          -- 1 = fullest 25%
       ROUND(PERCENT_RANK() OVER (ORDER BY load_pct)::numeric, 2) AS percent_rank
FROM (SELECT f.flight_number, f.origin, f.destination, fn_load_factor(f.flight_id) AS load_pct
      FROM FLIGHT f WHERE f.departure_time >= CURRENT_DATE + 1 AND f.departure_time < CURRENT_DATE + 2
        AND f.origin IN ('NQZ', 'ALA')) t
ORDER BY load_pct DESC;

-- Share of each route in its airline's revenue (window SUM without ORDER BY)
SELECT airline, route, revenue,
       ROUND(100.0 * revenue / SUM(revenue) OVER (PARTITION BY airline), 1) AS pct_of_airline
FROM (SELECT f.airline, f.origin || '→' || f.destination AS route, SUM(b.total_price) AS revenue
      FROM BOOKING b JOIN FLIGHT f ON f.flight_id = b.flight_id
      WHERE b.status <> 'Cancelled' AND f.airline = 'Air Astana'
      GROUP BY f.airline, f.origin, f.destination) t
ORDER BY revenue DESC;


-- =====================================================================
-- 13. QUERY OPTIMIZATION AND PERFORMANCE TUNING
--     EXPLAIN ANALYZE shows the plan PostgreSQL chose and the real time.
--     Numbers in comments were measured on our data (226 000 bookings).
-- =====================================================================

-- (a) A new index: bookings made on one day
--     without ix_booking_date: Parallel Seq Scan of all 226 000 rows, ≈ 12 ms
--     with    ix_booking_date: Bitmap Index Scan,                     ≈ 5 ms (busy day)
--                                Index Scan, day with few bookings,  ≈ 0.07 ms
EXPLAIN ANALYZE
SELECT COUNT(*), SUM(total_price) FROM BOOKING WHERE booking_date = CURRENT_DATE - 10;

-- (b) Rewriting a condition so the index can be used ("sargable")
--     BAD : departure_time::date = '…'  → the cast hides the column, index used for origin+destination only (≈ 0.14 ms)
--     GOOD: departure_time >= d AND < d+1 → Index Cond on all three columns                              (≈ 0.04 ms)
--     server.js now uses the GOOD form for flight search and the price calendar.
EXPLAIN ANALYZE
SELECT flight_id FROM FLIGHT
WHERE origin = 'IST' AND destination = 'LHR' AND departure_time::date = CURRENT_DATE + 5;
EXPLAIN ANALYZE
SELECT flight_id FROM FLIGHT
WHERE origin = 'IST' AND destination = 'LHR' AND departure_time >= CURRENT_DATE + 5 AND departure_time < CURRENT_DATE + 6;

-- (c) Materialized view instead of a heavy GROUP BY
--     live GROUP BY over FLIGHT ⟕ BOOKING:  ≈ 260 ms      analytics.mv_route_stats: ≈ 0.09 ms
EXPLAIN ANALYZE
SELECT f.origin, f.destination, COUNT(DISTINCT f.flight_id), SUM(b.total_price)
FROM FLIGHT f LEFT JOIN BOOKING b ON b.flight_id = f.flight_id
GROUP BY f.origin, f.destination;
EXPLAIN ANALYZE
SELECT * FROM analytics.mv_route_stats;

-- (d) A small table is read whole even with an index — the planner is right:
--     reading a few pages is cheaper than using the index.
EXPLAIN SELECT * FROM PAYMENT_METHOD WHERE payment_id = 2;

-- (e) Other tuning already in the project
--     • ANALYZE after loading data (seed.sql) so the planner has fresh statistics
--     • partial indexes skip cancelled bookings, which no query looks for
--     • bulk seed: the seat trigger is switched off for one INSERT … SELECT (safe by construction), 37 s → 14 s
--     • one SQL round trip per page: the bookings list uses json_agg instead of one query per ticket
SELECT relname AS table_name, n_live_tup AS rows, last_analyze, last_autoanalyze
FROM pg_stat_user_tables ORDER BY n_live_tup DESC LIMIT 10;
